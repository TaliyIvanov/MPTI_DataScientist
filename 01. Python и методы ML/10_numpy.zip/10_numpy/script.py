
def hello_printer():
    print('one more hello world')


hello_printer()
